import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import toast from "react-hot-toast";
import { Moon, Sun, Pencil, Trash2, X } from "lucide-react";

interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
}

type Theme = "light" | "dark";

const STORAGE_KEY_NOTES = "notes";
const STORAGE_KEY_THEME = "theme";

function formatDate(ts: number) {
  try {
    return new Date(ts).toLocaleString();
  } catch {
    return "";
  }
}

function App() {
  const [theme, setTheme] = useState<Theme>("light");

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const [notes, setNotes] = useState<Note[]>([]);
  const [editing, setEditing] = useState<Note | null>(null);

  const editTitleRef = useRef<HTMLInputElement | null>(null);
  const editContentRef = useRef<HTMLTextAreaElement | null>(null);

  // Load persisted state
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY_NOTES);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as Note[];
        setNotes(parsed);
      } catch {
        // ignore corrupted data
      }
    }

    const savedTheme = localStorage.getItem(STORAGE_KEY_THEME) as Theme | null;
    if (savedTheme === "dark" || savedTheme === "light") {
      setTheme(savedTheme);
    } else {
      // sensible default: system preference
      const prefersDark =
        typeof window !== "undefined" &&
        window.matchMedia &&
        window.matchMedia("(prefers-color-scheme: dark)").matches;
      setTheme(prefersDark ? "dark" : "light");
    }
  }, []);

  // Persist notes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_NOTES, JSON.stringify(notes));
  }, [notes]);

  // Apply & persist theme
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem(STORAGE_KEY_THEME, theme);
  }, [theme]);

  // Focus modal fields when opened
  useEffect(() => {
    if (!editing) return;
    const t = setTimeout(() => {
      editTitleRef.current?.focus();
      editTitleRef.current?.select();
    }, 50);
    return () => clearTimeout(t);
  }, [editing]);

  const canSave = useMemo(() => title.trim().length > 0 && content.trim().length > 0, [title, content]);

  const addNote = () => {
    if (!canSave) {
      toast.error("Completa título y contenido.");
      return;
    }
    const now = Date.now();
    const newNote: Note = {
      id: crypto.randomUUID(),
      title: title.trim(),
      content: content.trim(),
      createdAt: now,
      updatedAt: now,
    };
    setNotes((prev) => [newNote, ...prev]);
    setTitle("");
    setContent("");
    toast.success("Nota guardada");
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    toast.success("Nota eliminada");
  };

  const openEdit = (note: Note) => setEditing({ ...note });

  const closeEdit = () => setEditing(null);

  const saveEdit = () => {
    if (!editing) return;
    const t = editing.title.trim();
    const c = editing.content.trim();
    if (!t || !c) {
      toast.error("Completa título y contenido.");
      return;
    }
    const now = Date.now();
    setNotes((prev) =>
      prev.map((n) =>
        n.id === editing.id
          ? { ...n, title: t, content: c, updatedAt: now }
          : n
      )
    );
    setEditing(null);
    toast.success("Cambios guardados");
  };

  const onFormKeyDown: React.KeyboardEventHandler = (e) => {
    // Enter on title saves if possible
    if (e.key === "Enter" && (e.target as HTMLElement).tagName === "INPUT") {
      e.preventDefault();
      if (canSave) addNote();
    }
    // Ctrl/Cmd+Enter on textarea saves
    if (
      e.key === "Enter" &&
      ((e.ctrlKey || e.metaKey) && (e.target as HTMLElement).tagName === "TEXTAREA")
    ) {
      e.preventDefault();
      if (canSave) addNote();
    }
  };

  const onModalKeyDown: React.KeyboardEventHandler = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      closeEdit();
      return;
    }
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      saveEdit();
    }
  };

  return (
    <div className="page">
      <div className="bgOrbs" aria-hidden="true">
        <div className="orb orb1" />
        <div className="orb orb2" />
      </div>

      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden="true">📝</div>
          <div>
            <h1>Notas Personales</h1>
            <p>Guarda ideas rápidas, edítalas y mantenlas ordenadas.</p>
          </div>
        </div>

        <button
          className="iconBtn"
          onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
          aria-label="Cambiar tema"
          title="Cambiar tema"
        >
          {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
        </button>
      </header>

      <main className="layout">
        <section className="panel">
          <h2>Nueva nota</h2>

          <div className="form" onKeyDown={onFormKeyDown}>
            <label>
              <span>Título</span>
              <input
                type="text"
                placeholder="Ej: Llamar al dentista"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </label>

            <label>
              <span>Contenido</span>
              <textarea
                placeholder="Escribe aquí..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={6}
              />
            </label>

            <div className="hintRow">
              <span className="hint">
                Atajos: <kbd>Enter</kbd> (en título) o <kbd>Ctrl</kbd>+<kbd>Enter</kbd> (en contenido)
              </span>

              <button className="primaryBtn" onClick={addNote} disabled={!canSave}>
                Guardar nota
              </button>
            </div>
          </div>
        </section>

        <section className="panel">
          <div className="panelHeader">
            <h2>Mis notas</h2>
            <span className="badge">{notes.length}</span>
          </div>

          {notes.length === 0 ? (
            <div className="empty">
              <div className="emptyIcon">✨</div>
              <p><strong>No hay notas todavía.</strong></p>
              <p>Crea tu primera nota a la izquierda.</p>
            </div>
          ) : (
            <motion.div layout className="cards">
              <AnimatePresence initial={false}>
                {notes.map((note) => (
                  <motion.article
                    key={note.id}
                    layout
                    initial={{ opacity: 0, y: 10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.98 }}
                    transition={{ duration: 0.18 }}
                    className="card"
                  >
                    <div className="cardTop">
                      <div className="cardTitle">
                        <h3 title={note.title}>{note.title}</h3>
                        <p className="meta">Actualizada: {formatDate(note.updatedAt)}</p>
                      </div>

                      <div className="cardActions">
                        <button className="iconBtn" onClick={() => openEdit(note)} aria-label="Editar" title="Editar">
                          <Pencil size={18} />
                        </button>
                        <button className="iconBtn danger" onClick={() => deleteNote(note.id)} aria-label="Eliminar" title="Eliminar">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>

                    <p className="content">{note.content}</p>
                  </motion.article>
                ))}
              </AnimatePresence>
            </motion.div>
          )}
        </section>
      </main>

      <AnimatePresence>
        {editing && (
          <motion.div
            className="modalOverlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={(e) => {
              // close when clicking backdrop
              if (e.target === e.currentTarget) closeEdit();
            }}
            onKeyDown={onModalKeyDown}
            tabIndex={-1}
          >
            <motion.div
              className="modal"
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
              transition={{ duration: 0.18 }}
              role="dialog"
              aria-modal="true"
              aria-label="Editar nota"
            >
              <div className="modalHeader">
                <h3>Editar nota</h3>
                <button className="iconBtn" onClick={closeEdit} aria-label="Cerrar" title="Cerrar (Esc)">
                  <X size={18} />
                </button>
              </div>

              <div className="form">
                <label>
                  <span>Título</span>
                  <input
                    ref={editTitleRef}
                    type="text"
                    value={editing.title}
                    onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                  />
                </label>

                <label>
                  <span>Contenido</span>
                  <textarea
                    ref={editContentRef}
                    value={editing.content}
                    onChange={(e) => setEditing({ ...editing, content: e.target.value })}
                    rows={8}
                  />
                </label>

                <div className="hintRow">
                  <span className="hint">
                    Atajos: <kbd>Esc</kbd> cerrar · <kbd>Ctrl</kbd>+<kbd>Enter</kbd> guardar
                  </span>
                  <button className="primaryBtn" onClick={saveEdit}>
                    Guardar cambios
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="footer">
        <span>
          Tus notas se guardan en este navegador (localStorage).
        </span>
      </footer>
    </div>
  );
}

export default App;
